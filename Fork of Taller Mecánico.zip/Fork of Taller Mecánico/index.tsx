// ... (previous imports and code remain the same)

<section id="galeria" className="w-full py-12 md:py-24 lg:py-32 bg-black">
  <div className="container px-4 md:px-6">
    <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8 text-white">Galería</h2>
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <div className="space-y-2">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0410-u9LyGyFAnbiGF9g3jVD9H3142iGHl0.jpeg"
          alt="Motor de alto rendimiento Mercedes-Benz AMG"
          width={600}
          height={400}
          className="rounded-lg object-cover w-full"
        />
        <p className="text-sm text-gray-300">Acudimos hasta tu domicilio por tu vehículo, nuestra atención personalizada para cada uno de nuestros clientes que forman parte de esta marca en construcción</p>
      </div>
      <div className="space-y-2">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0403-7voAdOWx1Ul11wiKXmHpVBXuCjDDWY.jpeg"
          alt="Interior de vehículo de lujo"
          width={600}
          height={400}
          className="rounded-lg object-cover w-full"
        />
        <p className="text-sm text-gray-300">EuroStar consiente tu vehículo con el mismo amor e interés como tú lo harías, la confianza de los clientes habla por nosotros.</p>
      </div>
      <div className="space-y-2">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0404-4GB6oFL3vDMU1eLBcn0C4g71jzylbQ.jpeg"
          alt="Dodge Challenger personalizado"
          width={600}
          height={400}
          className="rounded-lg object-cover w-full"
        />
        <p className="text-sm text-gray-300">Los autos de más alta gama de Guatemala son vistos por EuroStar, somos especialistas en resolver tus necesidades.</p>
      </div>
    </div>
  </div>
</section>

// ... (rest of the code remains the same)